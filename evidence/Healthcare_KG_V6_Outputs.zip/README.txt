V6 research prototype. Deterministic guarded routing and retrieval; not an autonomous LLM agent, medical advice, or a treatment-eligibility estimator. Original clinical KG is read only.
