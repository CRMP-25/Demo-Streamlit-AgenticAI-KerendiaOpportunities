V5.1 review-only population KG layer. Clinical links are conceptual and not human-approved. No GitHub modifications. See validation report and full link adjudication ledger.
